package com.example.taskmanagement.util;

public enum TaskStatus {
    TODO,
    IN_PROGRESS,
    DONE
}