package com.example.taskmanagement.util;

public enum Role {
    USER,
    MANAGER
}