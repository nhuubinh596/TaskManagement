# DANH SÁCH QUY TẮC VALIDATE INPUT (TUẦN 6)

1. Tiêu đề (title): Bắt buộc nhập. Độ dài từ 5 đến 100 ký tự.
2. Mô tả (description): Không bắt buộc. Tối đa 500 ký tự.
3. Hạn chót (deadline): Bắt buộc nhập. Phải là ngày trong tương lai.
4. Mã dự án (projectId): Bắt buộc nhập.